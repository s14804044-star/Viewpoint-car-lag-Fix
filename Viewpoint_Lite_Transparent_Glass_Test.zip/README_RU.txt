Project Viewpoint — Lite + Transparent Glass TEST

This builds on the working Lite shader test. It keeps the simplified vehicle material shader, but restores window detection so Viewpoint can route window surfaces through its dedicated glass pass (which uses uGlassAlpha).

Install:
1. Close Project Zomboid.
2. Back up the currently working Viewpoint.jar.
3. Open Viewpoint.jar with any ZIP/JAR archive editor.
4. Replace exactly `viewpoint/shaders/lib/vehicle.glsl` with the file at that path in this ZIP.
5. Save and test a car in first-person view.

Expected: windows should be handled by Viewpoint's glass pass and may become transparent enough to see through. Exact appearance depends on Viewpoint's glass settings and the vehicle's zone mask. This is experimental; it is not guaranteed to make every vehicle's glass fully clear.

If windows turn opaque, disappear, or the game reports shader errors, restore the backup. Keep the working Lite patch safe.







#include "lib/hsv.glsl"
#include "lib/lanczos.glsl"
in vec2 vUv;
in vec2 vUv2;
uniform sampler2D uTexture;
uniform int uModelFilter;
uniform sampler2D uRustMap;
uniform sampler2D uZones;
uniform sampler2D uLamps;
uniform sampler2D uDamage1Overlay;
uniform sampler2D uDamage1Shell;
uniform sampler2D uDamage2Overlay;
uniform sampler2D uDamage2Shell;


uniform mat4 uSwitches[12];
uniform float uRust;
uniform vec3 uPaint;
uniform int uKind;
flat in vec4 vTint;
struct Vehicle {
  vec3 colour;
  float window;
  float gone;
  float paint;
  vec4 lamp;
};

vec3 zone(int z) {
  const vec3 ZONES[27] = vec3[27](
    vec3(1.0, 0.0, 0.0), vec3(0.0, 1.0, 0.0), vec3(0.0, 1.0, 1.0), vec3(1.0, 1.0, 0.0),
    vec3(1.0, 0.0, 1.0), vec3(0.0, 0.0, 1.0), vec3(0.0, 0.5, 0.5), vec3(0.5, 0.5, 0.0),
    vec3(0.5, 0.0, 0.5), vec3(0.0, 0.0, 0.5), vec3(0.5, 0.0, 0.0), vec3(0.0, 0.5, 0.0),
    vec3(0.0, 0.75, 0.75), vec3(0.75, 0.75, 0.0), vec3(0.75, 0.0, 0.75), vec3(0.0, 0.0, 0.75),
    vec3(0.0, 0.0, 0.0), vec3(0.25, 0.0, 0.0), vec3(0.75, 0.0, 0.0), vec3(0.0, 0.75, 0.0),
    vec3(0.0, 0.25, 0.0), vec3(0.5, 0.25, 0.0), vec3(0.5, 0.75, 0.0), vec3(0.75, 0.75, 0.75),
    vec3(0.25, 0.25, 0.25), vec3(1.0, 0.0, 0.5), vec3(0.0, 1.0, 0.5));
  const vec3 GUARDS[4] = vec3[4](vec3(0.75, 0.0, 0.75), vec3(0.0, 0.0, 0.75), vec3(0.0, 0.75, 0.75), vec3(0.75, 0.75, 0.0));
  return uKind == 0 && z >= 12 && z < 16 ? GUARDS[z - 12] : ZONES[z];
}

float vehicleWindow() {
  vec3 m = texture(uZones, vUv).rgb;
  float w = 0.0;
  for (int z = 6; z < 12; z++) w += 1.0 - step(0.01, length(m - zone(z)));
  return clamp(w, 0.0, 1.0);
}

float switched(int k, mat4 zones1, mat4 zones2) {
  mat4 a = transpose(uSwitches[k]), b = transpose(uSwitches[k + 1]);
  float sum = 0.0;
  for (int c = 0; c < 4; c++) sum += dot(zones1[c], a[c]) + dot(zones2[c], b[c]);
  return sum;
}

vec3 painted(vec3 col, vec3 paint) {
  vec3 hsv = rgb2hsv(col);
  hsv.x = paint.x;
  hsv.y = clamp(hsv.y + paint.y - 0.5, 0.0, 0.9999);
  hsv.z = clamp(hsv.z + paint.z - 0.5, 0.0, 0.9999);
  return hsv2rgb(mod(hsv, 1.0));
}

vec3 blood(vec4 overlay, vec4 mask, float intensity, float alpha, vec3 col) {
  float i = clamp(intensity, 0.0, 1.0);
  if (i < 0.0001) return col;
  float a = (1.0 - pow(1.0 - overlay.a, 3.0)) * (1.0 - pow(1.0 - mask.a, 3.0));
  a = clamp((a - (1.0 - i)) / i, 0.0, 1.0);
  return mix(col, overlay.rgb * a, a * overlay.a * alpha);
}



vec4 zonesAt(vec3 m, int first) {
  vec4 on = vec4(0.0);
  for (int k = 0; k < 4; k++) if (first + k < 27) on[k] = 1.0 - step(0.01, length(m - zone(first + k)));
  return on;
}
Vehicle vehicle() {
  // EXPERIMENTAL LITE TEST:
  // Skip material masks, rust, damage overlays, paint processing and lamp logic.
  // If this improves FPS, shader/material processing is likely involved.
  // This is diagnostic, not a final visual-quality patch.
  vec4 tex = texture(uTexture, vUv);
  Vehicle v;
  v.colour = tex.rgb * desaturate(vTint.rgb, 0.3);
  v.window = vehicleWindow();
  v.gone = 0.0;
  v.paint = 0.0;
  v.lamp = vec4(0.0);
  return v;
}
